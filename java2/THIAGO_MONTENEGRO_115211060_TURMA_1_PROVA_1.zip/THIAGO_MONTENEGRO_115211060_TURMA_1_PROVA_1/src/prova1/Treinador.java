package prova1;
import java.util.ArrayList;
public class Treinador {
	private String nomeTreinador;
	private ArrayList<Pokeagenda> pokemons;
	
	public Treinador(String nome){
		this.nomeTreinador = nome;
	}
	
	public quantosPokemons(pokemons){
		return size.pokeagenda();
	}
	
	public pokemonEspecifico(){
		for(Pokemons: pokemons){
			if(!contains(pokemons()) )
		}
	}
	
	
	public String toString(){
		return "Ola, sou " + nomeTreinador + "!" +
				"Meu poder total eh" + 
	}
}
