package prova1;
import java.util.ArrayList;

public class Pokeagenda {
	private ArrayList<Pokemon> pokeAgenda;
	

    public void addPokeAgenda(){
    	
    }
	public ArrayList<Pokemon> getPokeAgenda() {
		return pokeAgenda;
	}

	public void setPokeagenda(ArrayList<Pokemon> pokeAgenda) {
		this.pokeAgenda = pokeAgenda;
	}
	
}


